export type CardMessages = {
  select: string;
  loading: string;
};
