export type CarouselMessages = {
  previous: string;
  next: string;
  play: string;
  pause: string;
  carousel: string;
  carouselItemProgress: string;
};
